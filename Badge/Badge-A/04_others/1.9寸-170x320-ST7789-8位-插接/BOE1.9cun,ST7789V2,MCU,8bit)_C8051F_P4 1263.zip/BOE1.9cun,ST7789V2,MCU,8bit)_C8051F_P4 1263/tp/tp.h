#include "c8051F340.h"
#include <main.h>

extern void TP_DrawLine(void);
