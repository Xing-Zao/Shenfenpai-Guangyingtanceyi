/**
 * 光影探测仪 Firmware
 * Copyright (c) 2020-2021 LonlyPan. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
/*
 * @file         : \user\Mymain.c
 * @author       : LonlyPan
 * @version      : V0.0.0
 * @date         : 2021-02-06 14:12
 * @brief        : 主函数
 *                 初始化外设
 *                 开机显示
 *                 任务处理
 * @attention    : 
 */
#include "Mymain.h"
#include "gpio.h"
#include "tim.h"
#include "remoter.h"
#include "lcd.h"
#include "ws2812.h"
#include "servo.h"
#include "w25qxx.h"
#include "fatfs.h"
#include "text.h"
#include "task.h"

/**
 * @brief: 显示flash中name.txt文件中为文字
 * @note: 可使用USB连接，直接电脑修改该文件内容
 */
void show_flash_name()
{
	u8 name_buf[512] = " ";
	UINT num =1;
	u16 i = 0;
	/* Register the file system object to the FatFs module */
	if(f_mount(&USERFatFS, "0:", 0) == FR_OK)
	{
		//* Create and Open a new text file object with write access */
		if(f_open(&USERFile, "name.txt", FA_READ) == FR_OK) // FA_WRITE  identity_true_blue.bin
		{
			 f_lseek(&USERFile,0);
			 while(num != 0){
				 f_read(&USERFile,name_buf+i,1,&num);
				i++;
			 }
			 f_close(&USERFile);
		}
		f_mount(NULL, "0:", 0);
	}
	if(i > 1){
		Show_Str(0,42,240,38,name_buf,32,1);
	}
}


/**
 * @brief:  基本任务轮询
 * @note: 需要持续调用以维持系统基本运行，如函数阻塞则须在阻塞函数中单独调用该函数
 */
void idle()
{
	key_process();
}


/**
 * @brief: 初始化函数
 */
void setup()
{

	delay_init(84); /* 延时函数初始化 */
	IR_init();      /* 红外发射初始化 */
	LCD_Init();     /* LCD初始化 */

	ws281x_init();  /* ws281x初始化 */
	servo_init();   /* 舵机初始化 */
	W25QXX_Init();  /* W25Q256-Flash初始化 */
	while(W25QXX_ReadID()!=W25Q256)
	{
		LCD_ShowString(50,50,200,35,16,(u8 *)"W25Q64 Failed!",1);
	}
	LCD_ShowString(50,50,200,35,16,(u8 *)"W25Q64 OK!",1);
	HAL_Delay(500);   //  开机自检

    (*currentMode)(); /* 进入开机运行模式 */
}

/**
 * @brief: 主循环
 */
void loop()
{
    idle();
    (*currentMode)();
}
