/**
 * 项目名 Firmware
 * Copyright (c) 2020-2021 LonlyPan. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
/*
 * @file         : ws2812.h
 * @author       : LonlyPan
 * @version      : V1.0.0
 * @date         : 2021-02-01 14:12
 * @brief        : ws2812 ws2812 驱动及样式
 * @attention    : 由于采用DMA传输，数组中每个元素表示高低电平脉冲值，即 1 bit，每8个元素表述一位，
                   每个灯由 RGB 三色表示，每一个颜色由一位表示，则每个灯需要24个元素表示
 * @Modification : 初始版本
 * @LastEditTime : 2021-05-07 10:19
 * @History      : 
 *   1.Version: 
 *     Author:
 *     date:    
 *     Modification: 
 *   2.Version: 
 *     ......
 */
#ifndef WS2812_H_
#define WS2812_H_

#include "Comheader.h"

// 主色RGB值 橙黄色
#define MAIN_COLOR_R 126
#define MAIN_COLOR_G 40
#define MAIN_COLOR_B 0

#define DELAY_LEN 240  /* 延时复位计数值，复位时间 > 280us　＝　DELAY_LEN*脉冲周期1.25us = 300us*/
#define LED_NUM  61    /* 所有组LED个数和  */
#define LED_GROUP 2    // 一共两组灯带：正面灯带+侧面环形灯带
#define ARRAY_LEN (DELAY_LEN + LED_NUM*24)  // 该宏定义表示 RGB 缓存全局数组长度，复位延时计数值+LED数量*24 
                                            // 由于采用DMA传输，复位的实现也是通过数组传递数据，对应数据全为0即低电平
#define LED_1_PULSE 71  // 定时器比较寄存器值，数据1高电平0.85us对应的计数值。定时器重装载值105，一个数据脉冲周期1.25us  频率800KHz
#define LED_0_PULSE 34  // 数据0高电平0.4us对应的计数值

/*************************** 头部灯带数量分布示意 ************************/
/*灯位置：   两翼灯1  无效灯     前灯   无效灯  中央灯   无效灯   前灯   无效灯    两翼灯2
 *         oooooooo   oooo   oooooooo   o       o       o    oooooooo  oooo   oooooooo
 *灯数量：     18       4        7       1       1       1       7       4        18
 *
 */

#define LED_HEAD_NUM_ALL 61    // 前灯总数
#define LED_RING_NUM_ALL 24    // 环灯总数
#define LED_WING_NUM  18       // 单侧翼灯总数
#define LED_FRONT_NUM  7       // 单侧翼灯总数

// 灯带组索引
enum RGB_LED_GROUP
{
    RGB_LED_FRONT=0,
    RGB_LED_RING
};

/**
 * @brief  ws2812B初始化，灯全灭
 */
void ws281x_init(void);

/**
 * @brief  熄灭所有灯
 */
void ws281x_cloase_all();

/**
 * @brief: 设置指定LED的颜色只
 * @note: 
 * @param {uint8_t} Rpixel，Gpixel，Bpixel RGB值0-255
 * @param {uint16_t} groupX 三色灯所在灯组（每个灯组使用同一DMA通道）
 * @param {uint16_t} posX 灯位置索引
 */
void ws281x_set_Pixe_rgb_buf(uint8_t Rpixel , uint8_t Gpixel, uint8_t Bpixel, uint16_t groupX, uint16_t posX);

void ws281x_set_group_all_rgb_buf(uint8_t Rpixel , uint8_t Gpixel, uint8_t Bpixel, uint16_t groupX);

void ws281x_set_all_rgb_buf_light(uint8_t Rpixel , uint8_t Gpixel, uint8_t Bpixel);
void ws281x_set_ring_all_rgb_buf(uint8_t Rpixel , uint8_t Gpixel, uint8_t Bpixel);

void ws2812_test_prepare(void);
void ws2812_test01(void);
void ws2812_test02(void);
void ws2812_test03(void);
void ws2812_test04(uint8_t col);
void ws2812_test05(void);
void ws2812_ring_test1();
void ws2812_front_test1();
/**
 * @brief  启动DMA-PWM传输。
 * @note
 * @param
 * @retval     xxx  // 返回值
 */
void ws281x_light(uint16_t groupX);


void ws281x_qiandeng_light();
void ws281x_qiandeng_light2();

//--------------------------------------------------

#endif /* WS2812_H_ */
