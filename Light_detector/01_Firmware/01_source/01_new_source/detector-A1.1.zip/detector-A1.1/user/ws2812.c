/**
* 光影探测仪 Firmware
* Copyright (c) 2020-2021 LonlyPan. All rights reserved.
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <https://www.gnu.org/licenses/>.
*
*/
/*
 * @file         : ws2812.c
 * @author       : LonlyPan
 * @version      : V0.0.0
 * @date         : 2021-03-17 08:59
 * @brief        : ws2812 ws2812 驱动及样式
 * @attention    : 
 */
#include "ws2812.h"
#include "tim.h"
#include <string.h>
#include <stdint.h>

/* RGB 缓存全局数组，每8个元素表示8bit = 1个像素的值，每24个元素表示一个LED的三个像素RGB值，RGB依次循环排列
  *  每个元素值范围 0-255
  *  仅在该源文件中使用，先将LED的RGB值存储到该数组中，再调用 ws281x_light() 启动DMA传输，即可完成LED的控制
 */
static uint32_t BUF_DMA[LED_GROUP][ARRAY_LEN] = {0};

void ws281x_init(void)
{
	ws281x_cloase_all();
}

/**
 * @brief: 关闭所有LED灯
 * @note: 一共两个灯带：正面灯带+侧面环形灯带
 */
void ws281x_cloase_all()
{
	for(int i=0;i<LED_GROUP;i++) {
		for(int j=DELAY_LEN;j<ARRAY_LEN;j++)
			BUF_DMA[i][j] = LED_0_PULSE;
	}

	HAL_TIM_PWM_Start_DMA(&htim5,TIM_CHANNEL_2,(uint32_t *)BUF_DMA[0],ARRAY_LEN);
	delay_ms(10);//等待数据传输完成

    HAL_TIM_PWM_Start_DMA(&htim5,TIM_CHANNEL_3,(uint32_t *)BUF_DMA[1],ARRAY_LEN);
    delay_ms(10);//
}

/**
 * @brief: 设置指定LED的颜色
 * @note: 
 * @param {uint8_t} Rpixel，Gpixel，Bpixel RGB值0-255
 * @param {uint16_t} groupX 三色灯所在灯组（每个灯组使用同一DMA通道）
 * @param {uint16_t} posX 灯位置索引
 */

void ws281x_set_Pixe_rgb_buf(uint8_t Rpixel , uint8_t Gpixel, uint8_t Bpixel, uint16_t groupX, uint16_t posX)
{
	uint32_t GRBcolor = Gpixel << 16 | Rpixel << 8 | Bpixel;
    // 将RGB值转为DMA数组值
	for(u8 i=0;i<24;i++)
	{   
		BUF_DMA[groupX][DELAY_LEN+24 * posX + i] = (((GRBcolor << i) & 0X800000) ? LED_1_PULSE : LED_0_PULSE);
	}
}

/**
 * @brief: 设置指定组所有LED为相同颜色
 * @note: 每个灯组所有灯颜色相同
 * @param {uint8_t} Rpixel，Gpixel，Bpixel RGB值0-255
 * @param {uint16_t} groupX 三色灯所在灯组（每个灯组使用同一DMA通道）
 */
void ws281x_set_group_all_rgb_buf(uint8_t Rpixel , uint8_t Gpixel, uint8_t Bpixel,  uint16_t groupX)
{
	uint32_t BUF_DMA_TEMP[24];
	uint32_t GRBcolor = Gpixel << 16 | Rpixel << 8 | Bpixel;
	for(u8 i=0;i<24;i++)
	{
		BUF_DMA_TEMP[i] = (((GRBcolor << i) & 0X800000) ? LED_1_PULSE : LED_0_PULSE);
	}

	for(u8 i=0;i<LED_NUM;i++){
		for (u8 j = 0; j < 24; j++){
			BUF_DMA[groupX][DELAY_LEN+i * 24 + j] = BUF_DMA_TEMP[j];
		}
	}
}

/**
 * @brief: 设置所有LED为相同颜色并点亮
 * @note: 所有灯颜色相同
 * @param {uint8_t} Rpixel，Gpixel，Bpixel RGB值0-255
 */
void ws281x_set_all_rgb_buf_light(uint8_t Rpixel , uint8_t Gpixel, uint8_t Bpixel)
{
	uint32_t BUF_DMA_TEMP[24];
	uint32_t GRBcolor = Gpixel << 16 | Rpixel << 8 | Bpixel;
	for(u8 i=0;i<24;i++)
	{
		BUF_DMA_TEMP[i] = (((GRBcolor << i) & 0X800000) ? LED_1_PULSE : LED_0_PULSE);
	}
	for(u8 g =0;g<LED_GROUP;g++){
		for(u8 i=0;i<LED_NUM;i++){
			for (u8 j = 0; j < 24; j++){
				BUF_DMA[g][DELAY_LEN+i * 24 + j] = BUF_DMA_TEMP[j];
			}
		}
	}
	HAL_TIM_PWM_Start_DMA(&htim5,TIM_CHANNEL_2,(uint32_t *)BUF_DMA[0],ARRAY_LEN);  //
	delay_ms(5);
  	HAL_TIM_PWM_Start_DMA(&htim5,TIM_CHANNEL_3,(uint32_t *)BUF_DMA[1],ARRAY_LEN);
  	delay_ms(5);
}

/**
 * @brief: 点亮指定灯组
 * @note: 需要提前设置每个灯组的颜色
 * @param {uint16_t} groupX 三色灯所在灯组（每个灯组使用同一DMA通道）
 */
void ws281x_light(uint16_t groupX)
{
	switch(groupX){
	  case 0:
		  HAL_TIM_PWM_Start_DMA(&htim5,TIM_CHANNEL_2,(uint32_t *)BUF_DMA[0],ARRAY_LEN);
		  break;
	  case 1:
		  HAL_TIM_PWM_Start_DMA(&htim5,TIM_CHANNEL_3,(uint32_t *)BUF_DMA[1],ARRAY_LEN);
		  break;
	  default:
		  break;
	};
}


// RGB数组，存储预设的RGB值，最多8组数据即八个灯
uint8_t rgb_temp[8][3];
// DMA临时数组，存储上面的RGB数组值
uint32_t DMA_BUF_TEMP[24];

/**
 * @brief: 向LED数组里预设填充RGB值
 * @note:  每三个数据为一组表示一个灯，共8个灯
 * @param {uint8_t} rxx，gxx，bxx RGB值0-255
 */
void ws2812_prepareValue (uint8_t r00, uint8_t g00, uint8_t b00,
    uint8_t r01, uint8_t g01, uint8_t b01,
    uint8_t r02, uint8_t g02, uint8_t b02,
    uint8_t r03, uint8_t g03, uint8_t b03,
    uint8_t r04, uint8_t g04, uint8_t b04,
    uint8_t r05, uint8_t g05, uint8_t b05,
    uint8_t r06, uint8_t g06, uint8_t b06,
    uint8_t r07, uint8_t g07, uint8_t b07)
{
	rgb_temp[0][0]=r00; rgb_temp[0][1]=g00; rgb_temp[0][2]=b00;
	rgb_temp[1][0]=r01; rgb_temp[1][1]=g01; rgb_temp[1][2]=b01;
	rgb_temp[2][0]=r02; rgb_temp[2][1]=g02; rgb_temp[2][2]=b02;
	rgb_temp[3][0]=r03; rgb_temp[3][1]=g03; rgb_temp[3][2]=b03;
	rgb_temp[4][0]=r04; rgb_temp[4][1]=g04; rgb_temp[4][2]=b04;
	rgb_temp[5][0]=r05; rgb_temp[5][1]=g05; rgb_temp[5][2]=b05;
	rgb_temp[6][0]=r06; rgb_temp[6][1]=g06; rgb_temp[6][2]=b06;
	rgb_temp[7][0]=r07; rgb_temp[7][1]=g07; rgb_temp[7][2]=b07;

}

/**
 * @brief  循环设置环形灯带RGB，每八个灯重复一次
 * @note   需提前调用 ws2812_prepareValue 预设RGB数组值
 */
void ws2812_set_ring_Value(void)
{
  uint8_t n=0;
  for(n=0;n<(LED_RING_NUM_ALL/8);n++)
  {
	ws281x_set_Pixe_rgb_buf( rgb_temp[0][0], rgb_temp[0][1], rgb_temp[0][2], RGB_LED_RING, n*8);
    ws281x_set_Pixe_rgb_buf( rgb_temp[1][0], rgb_temp[1][1], rgb_temp[1][2], RGB_LED_RING, n*8+1);
    ws281x_set_Pixe_rgb_buf( rgb_temp[2][0], rgb_temp[2][1], rgb_temp[2][2], RGB_LED_RING, n*8+2);
    ws281x_set_Pixe_rgb_buf( rgb_temp[3][0], rgb_temp[3][1], rgb_temp[3][2], RGB_LED_RING, n*8+3);
    ws281x_set_Pixe_rgb_buf( rgb_temp[4][0], rgb_temp[4][1], rgb_temp[4][2], RGB_LED_RING, n*8+4);
    ws281x_set_Pixe_rgb_buf( rgb_temp[5][0], rgb_temp[5][1], rgb_temp[5][2], RGB_LED_RING, n*8+5);
    ws281x_set_Pixe_rgb_buf( rgb_temp[6][0], rgb_temp[6][1], rgb_temp[6][2], RGB_LED_RING, n*8+6);
    ws281x_set_Pixe_rgb_buf( rgb_temp[7][0], rgb_temp[7][1], rgb_temp[7][2], RGB_LED_RING, n*8+7);
  }
}


/**
 * @brief: 环形灯波浪流水灯
 * @note:  灯的亮度成正选曲线，并整体流水移动
 * @detail:
 */
void ws2812_ring_test1()
{
    for(uint8_t i=0;i<8;i++)  // 预填充RGB数组，值呈波浪形
    {
	  if(i<4)  // 亮度递减
		{rgb_temp[i][0]=MAIN_COLOR_R+MAIN_COLOR_R/((i+1)*2); rgb_temp[i][1]=MAIN_COLOR_G+MAIN_COLOR_G/((i+1)*2);; rgb_temp[i][2]=MAIN_COLOR_B;}
	  else     // 亮度递增
		{rgb_temp[i][0]=MAIN_COLOR_R+MAIN_COLOR_R/((8-i)*2); rgb_temp[i][1]=MAIN_COLOR_G+MAIN_COLOR_G/((8-i)*2); rgb_temp[i][2]=MAIN_COLOR_B;}
    }
   ws2812_set_ring_Value();  // 设置环形灯RGB值
   ws281x_light(RGB_LED_RING); // 点亮环形灯

   for(uint8_t j=0;j<LED_RING_NUM_ALL*2;j++)  // LED旋转，2圈
   {
     // 按字节复制 一个灯占24个字节 RGB 3 色*8位 = 24位
     memcpy((void*)DMA_BUF_TEMP,(void*)(BUF_DMA[RGB_LED_RING]+DELAY_LEN),24); // 保留第一个灯的颜色值
     // 灯带颜色整体移动一个像素点（一个灯）
     for(uint8_t i=0;i<(LED_RING_NUM_ALL-1);i++)
     {
       memcpy((void*)(i*24+BUF_DMA[RGB_LED_RING]+DELAY_LEN),(void*)(i*24+BUF_DMA[RGB_LED_RING]+DELAY_LEN+24),24); // 将后一个灯颜色值复制到前一个灯，实现整体偏移
     }
     memcpy((void*)(BUF_DMA[RGB_LED_RING]+DELAY_LEN+(LED_RING_NUM_ALL-1)*24),(void*)DMA_BUF_TEMP,24);  // 将第一个灯的值复制到最后一个灯
     ws281x_light(RGB_LED_RING);
     HAL_Delay(50);
  }
}


#define NEXT_CHANGE_TIME 0
/**
 * @brief: 前灯流水灯，强弱强弱变化
 * @note:  整体流水移动
 * @detail:
 */
void ws2812_front_test1()
{
	// 强弱强弱变化
    ws281x_set_Pixe_rgb_buf( MAIN_COLOR_R, MAIN_COLOR_G, MAIN_COLOR_B, RGB_LED_FRONT, 18+4+7+1); // 设置中心灯颜色

    millis_t now = millis(); // current time in ms.
    static millis_t s_NextTime = 0; // will be set in state 1
    static u8 change_num = 0;
    if(ELAPSED(now,s_NextTime)){
        s_NextTime = now + NEXT_CHANGE_TIME;
        if(change_num){
            change_num = 0;
            for(int n=0;n<LED_FRONT_NUM;n++){
                ws281x_set_Pixe_rgb_buf( MAIN_COLOR_R*2, MAIN_COLOR_G*2, MAIN_COLOR_B*2, RGB_LED_FRONT,18+4+n);
                ws281x_set_Pixe_rgb_buf( MAIN_COLOR_R*2, MAIN_COLOR_G*2, MAIN_COLOR_B*2, RGB_LED_FRONT,38-n);

                n++;
                ws281x_set_Pixe_rgb_buf( MAIN_COLOR_R, MAIN_COLOR_G, MAIN_COLOR_B,RGB_LED_FRONT,18+4+n);
                ws281x_set_Pixe_rgb_buf( MAIN_COLOR_R, MAIN_COLOR_G, MAIN_COLOR_B, RGB_LED_FRONT,38-n);
            }
        }
        else{
            change_num = 1;
            for(int n=0;n<LED_FRONT_NUM;n++){
                ws281x_set_Pixe_rgb_buf( MAIN_COLOR_R, MAIN_COLOR_G, MAIN_COLOR_B, RGB_LED_FRONT,18+4+n);
                ws281x_set_Pixe_rgb_buf( MAIN_COLOR_R, MAIN_COLOR_G, MAIN_COLOR_B, RGB_LED_FRONT,38-n);


                n++;
                ws281x_set_Pixe_rgb_buf( MAIN_COLOR_R*2, MAIN_COLOR_G*2, MAIN_COLOR_B*2, RGB_LED_FRONT,18+4+n);
                ws281x_set_Pixe_rgb_buf( MAIN_COLOR_R*2, MAIN_COLOR_G*2, MAIN_COLOR_B*2, RGB_LED_FRONT,38-n);
            }
        }
        ws281x_light(RGB_LED_FRONT);
    }
}
 
//------------------------------------------------------------------
