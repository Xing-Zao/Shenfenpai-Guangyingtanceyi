/**
 * 光影探测仪 Firmware
 * Copyright (c) 2020-2021 LonlyPan. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
/*
 * @file         : onebutton.c
 * @author       : LonlyPan
 * @version      : V0.0.0
 * @date         : 2020-05-31
 * @brief        : 用于检测按钮上的按钮单击，双击和长按模式的库。
 *                 移植自：http://www.mathertel.de/Arduino/OneButtonLibrary.aspx
 * @attention    : 电源开/关 按键时连续触发，其余为单次触发
 *                 连续触发：无需等待用户释放按键，只要按键时常满足要求，就认为有效
 *                 单次触发：需等待用户释放，如果用户不释放按键，仅认为一次有效
 * @Modification : 初始版本
 * @LastEditTime : 2021-05-08 09:02
 * @History      : 
 *   1.Version: 
 *     Author:
 *     date:    
 *     Modification: 
 *   2.Version: 
 *     ......
 */
#ifndef KEY_H_
#define KEY_H_


#include "Comheader.h"
#include "main.h"

/* 按键状态 */
enum KEY_STATUS{
    NO_CLICK,        /* 没有动作 */
    SINGLE_CLICK,    /* 单击 */
    DOUBLE_CLICK,    /* 双击 */
    LONGLE_CLICK     /* 长按 */
};

// 按键低电平有效
#define BUTTON_PRESSED  (HAL_GPIO_ReadPin(KEY_GPIO_Port, KEY_Pin)!=1)

/**
 * @brief: 按键扫描状态机（FSM）
 * @note: 非阻塞，依赖系统SysTick。仅适用单个按键
 * @retval: key_status 按键状态 （单次触发） 
 */
u8 button_tick(void);

#endif /* KEY_H_ */
