/**
 * 光影探测仪 Firmware
 * Copyright (c) 2020-2021 LonlyPan. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
/*
 * @file         : onebutton.c
 * @author       : LonlyPan
 * @version      : V0.0.0
 * @date         : 2020-05-31
 * @brief        : 用于检测按钮上的按钮单击，双击和长按模式的库。
  *                移植自：http://www.mathertel.de/Arduino/OneButtonLibrary.aspx
 * @attention    : 
 */

#include "key.h"

#define DEBOUNCETIME  50 // ms 按键去抖时间
#define CLICKTIME  100  // ms 检测到单击之前必须经过的时间
#define LONGTIME  1500 // ms 检测到长按之前必须经过的时间

// 这些变量在按键检测时保存信息。
// 它们在程序启动时初始化一次，并在每次调用key_scan()函数时更新。
static u8 s_state = 0;
static millis_t s_startTime = 0; // will be set in state 1
static millis_t s_stopTime = 0; // will be set in state 2

/**
 * @brief: 按键扫描状态机（FSM）
 */
u8 button_tick(void)
{
    u8 key_status = 0;
    millis_t now = millis(); // current time in ms.

    if (s_state == 0) { // waiting for pin being pressed.
        if (BUTTON_PRESSED) {
            s_state = 1; // step to state 1
            s_startTime = now; // remember starting time
        }
        else
            key_status = NO_CLICK;
    }
    else if (s_state == 1) { // waiting for pin being released.

        if ((!BUTTON_PRESSED) && ((unsigned long)(now - s_startTime) < DEBOUNCETIME)) {
            // 按键释放太快，认为事抖动，返回状态0，不任何动作
            s_state = 0;
        }
        else if (!BUTTON_PRESSED) {
            s_state = 2; // step to state 2
            s_stopTime = now; // remember stopping time
        }
        else if ((BUTTON_PRESSED) && ((unsigned long)(now - s_startTime) > LONGTIME)) {
            s_state = 6; // step to state 6
            s_stopTime = now; // remember stopping time
        } else {
            // Button was pressed down. wait. Stay in this state.
        } // if
    }
    else if (s_state == 2) {
        // waiting for menu pin being pressed the second time or timeout.
        if ((unsigned long)(now - s_startTime) > CLICKTIME) {
            // this was only a single short click
            key_status = SINGLE_CLICK;
            s_state = 0; // restart.
        } else if ((BUTTON_PRESSED) && ((unsigned long)(now - s_stopTime) > DEBOUNCETIME)) {
            s_state = 3; // step to state 3
            s_startTime = now; // remember starting time
        } // if
    }
    else if (s_state == 3) { // waiting for menu pin being released finally.
        // Stay here for at least _debounceTicks because else we might end up in
        // state 1 if the button bounces for too long.
        if ((!BUTTON_PRESSED) && ((unsigned long)(now - s_startTime) > DEBOUNCETIME)) {
            // this was a 2 click sequence.
            key_status = DOUBLE_CLICK;
            s_state = 0; // restart.
            s_stopTime = now; // remember stopping time
        } // if
    }
    else if (s_state == 6) {  /* 长按状态处理 */
        // waiting for pin being release after long press.
        if (!BUTTON_PRESSED) {
            s_state = 0; // restart.
            s_stopTime = now; // remember stopping time
        } else {
            // button is being long pressed
            key_status =  LONGLE_CLICK;
        } // if
    } // if
    return key_status;
} // OneButton.tick()



