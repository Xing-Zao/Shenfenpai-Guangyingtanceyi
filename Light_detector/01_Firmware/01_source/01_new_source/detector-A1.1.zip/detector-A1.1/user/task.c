/**
 * 光影探测仪 Firmware
 * Copyright (c) 2020-2021 LonlyPan. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
/*
 * @file         : \user\task.c
 * @author       : LonlyPan
 * @version      : V0.0.0
 * @date         : 2021-03-13 17:15
 * @brief        : 主要功能实现，系统的每种工作状态
 * @attention    : 如若要添加新的功能，请在对应状态函数中修改
 */
#include "remoter.h"

#include "task.h"
#include "ws2812.h"
#include "lcd.h"
#include "key.h"
#include "servo.h"

// 函数指针
modeFunc_t currentMode = power_off_mode;

// 系统运行状态
static u8 is_running = 0;

/**
 * @brief: 按键处理函数
 * @note:  
 * @detail: key_value 状态不会保持保存
 */
void key_process(void)
{
	static u8 turn_flag = 0;
    u8 key_value = button_tick();   //按键状态 0 ：无动作  1：点按  2：双击  3：长按
    switch(key_value){

      case NO_CLICK:
          break;
      case SINGLE_CLICK:
    	  if(is_running && turn_flag == 0){
    		  currentMode = wing_turn_mode;
    		 turn_flag = 1;
    	  }
          else if(is_running && turn_flag == 1){
    		  currentMode = modify_mode;
    		  turn_flag = 2;
    	  }
    	  else if(is_running && turn_flag == 2){
    		  currentMode = power_on_mode;
    		  turn_flag = 0;
    	  }
          break;
      case DOUBLE_CLICK:        // 双击直接在此处理
          break;
      case LONGLE_CLICK:        // 长按直接在此处理
    	  if(!is_running){
    		  currentMode = power_on_mode;
    		  is_running = 1;
    	  }
    	  else{
    		  currentMode = power_off_mode;
    		  is_running = 0;
    	  }
          break;
      default:
          break;

    }
}

/**
 * @brief: 待机模式
 * @note: 什么也不做，空跑
 * @detail:
 */
void standby_mode()
{

}

/**
 * @brief: 关机模式
 * @note:  软关机
 * @detail:
 */
void power_off_mode()
{
	servo_set_angle(104);
	ws281x_cloase_all();
	LCD_shutdown();
	delay_ms(3000);  /* 延时，防止用户按住不松手，反复开关机 */
	currentMode = standby_mode;
}

/**
 * @brief: 开机模式
 * @note:  环灯跑马灯效果会持续一段时间，期间任何操作无效
 * @detail:
 */
void power_on_mode()
{
	IR_Send(74);
	delay_ms(100);
	LCD_turnon();  // 打开 LCD
    LCD_Flash_Pic(0,0,176,220,"page1.bin"); // 显示图片
	servo_set_angle(104); // 舵机复位
    // WS281x 配置
	ws281x_set_group_all_rgb_buf(0, 0, 0, RGB_LED_FRONT);
	for(int i=0;i<LED_WING_NUM;i++){
		int wing2_num = LED_HEAD_NUM_ALL-1 - i;
		ws281x_set_Pixe_rgb_buf(MAIN_COLOR_R, MAIN_COLOR_G, MAIN_COLOR_B, RGB_LED_FRONT,i);
		ws281x_set_Pixe_rgb_buf(MAIN_COLOR_R, MAIN_COLOR_G, MAIN_COLOR_B, RGB_LED_FRONT,wing2_num);
	}
	ws281x_light(RGB_LED_FRONT); /* 仅两翼灯点亮 */
	delay_ms(5);

    ws2812_ring_test1(); /* 环形的亮起，会有阻塞 */
	currentMode = normal_mode;
}

/**
 * @brief: 开机之后进入的模式
 * @note:  无动作，等待
 * @detail:
 */
void normal_mode()
{

}


/**
 * @brief  两翼旋转的模式1
 * @note   前灯亮起，舵机旋转
 * @attention
 * @detail
 */
void wing_turn_mode()
{
	int i=0;	ws281x_set_group_all_rgb_buf(0, 0, 0, RGB_LED_FRONT);
	for(i=0;i<LED_HEAD_NUM_ALL;i++){
		ws281x_set_Pixe_rgb_buf(MAIN_COLOR_R,MAIN_COLOR_G, MAIN_COLOR_B, RGB_LED_FRONT,i);
	}
	ws281x_light(RGB_LED_FRONT); 
	delay_ms(5);
    servo_set_angle(30);  // 枪头旋转
    delay_ms(300);
    servo_set_angle(0);  // 枪头旋转

    currentMode = wing_turn_next_mode;
}
/**
 * @brief  两翼旋转的模式2
 * @note   前灯亮起，且跑马灯效果。由 wing_turn_mode() 自动调用
 * @attention
 * @detail
 */
void wing_turn_next_mode()
{

    millis_t now = millis(); // current time in ms.
    static millis_t s_NextTime = 0; // will be set in state 1
    static uint8_t page_toggle = 0;
    if(ELAPSED(now,s_NextTime)){
    	s_NextTime = now + 300;
    	if(!page_toggle){
    		page_toggle = 1;
    		LCD_Flash_Pic(0,0,176,220,"page2.bin");  // 身份读取修改中
    	}
    	else{
    		page_toggle = 0;
    		LCD_Flash_Pic(0,0,176,220,"page1.bin");  // 背景图
    	}
    }
    ws2812_front_test1();
}

/**
 * @brief  修改模式
 * @note   前灯爆闪，两翼收起且回正
 * @attention
 * @detail
 */
void modify_mode()
{

	int i=0;
	servo_set_angle(0);
	ws281x_set_group_all_rgb_buf(0, 0, 0, RGB_LED_FRONT);
	for(i=0;i<LED_HEAD_NUM_ALL;i++){
		ws281x_set_Pixe_rgb_buf(255,80,0, RGB_LED_FRONT,i);
	}
	ws281x_light(RGB_LED_FRONT);
	delay_ms(200);

	LCD_Flash_Pic(0,0,176,220,"page3.bin");

	for(i=0;i<LED_HEAD_NUM_ALL;i++){
		ws281x_set_Pixe_rgb_buf(0,0,0, RGB_LED_FRONT,i);
		ws281x_set_Pixe_rgb_buf(0,0,0, RGB_LED_FRONT,61-1-i);
		ws281x_light(RGB_LED_FRONT);
		delay_ms(10);
	}

	ws281x_set_group_all_rgb_buf(0, 0, 0, RGB_LED_FRONT);
	ws281x_light(RGB_LED_FRONT);
	delay_ms(5);
	ws281x_set_group_all_rgb_buf(0, 0, 0, RGB_LED_RING);
	ws281x_light(RGB_LED_RING);
	delay_ms(100);
	IR_Send(24);
	delay_ms(1000);

	currentMode = standby_mode;
}
