/**
 * 光影探测仪 Firmware
 * Copyright (c) 2020-2021 LonlyPan. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
/*
 * @file         : \user\delay.c
 * @author       : LonlyPan
 * @version      : V0.0.0
 * @date         : 2021-01-15 14:12
 * @brief        : 延时函数，使用系统SysTick
 * @attention    : 
 * @Modification : 初始版本
 * @LastEditTime : 2021-05-07 18:07
 * @History      : 
 *   1.Version: 
 *     Author:
 *     date:    
 *     Modification: 
 *   2.Version: 
 *     ......
 */
/*
 * delay.h
 *
 *  Created on: 2021年1月15日
 *      Author: 23714
 */

#ifndef DELAY_H_
#define DELAY_H_

#include "cc.h"

void delay_init(u8 SYSCLK);
void delay_ms(u16 nms);
void delay_us(u32 nus);


#endif /* DELAY_H_ */
