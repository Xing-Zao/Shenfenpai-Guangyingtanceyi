/**
 * 光影探测仪 Firmware
 * Copyright (c) 2020-2021 LonlyPan. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
/*
 * @file         : \user\remoter.h
 * @author       : LonlyPan
 * @version      : V0.0.0
 * @date         : 2021-01-06 14:12
 * @brief        : 红外遥控驱动
 * @attention    : 
 * @Modification : 初始版本
 * @LastEditTime : 2021-05-08 11:36
 * @History      : 
 *   1.Version: 
 *     Author:
 *     date:    
 *     Modification: 
 *   2.Version: 
 *     ......
 */
#ifndef REMOTER_H_
#define REMOTER_H_

#include "tim.h"
#include "Comheader.h"

#define IR_time htim1             // 红外发射 定时器
#define IR_Channel TIM_CHANNEL_2  // 红外发射 定时器通道

//不同遥控器数据码和键值对应不同
//数据码  按键值
//0:ERROR
//162:1
//98: 2
//226:3
//34: 4
//2:  5
//194:6
//224:7
//168:8
//144:9
//104:*
//152:0
//176:#
//24: UP
//16: LEFT
//90: RIGHT
//74: DOWN
//56: OK
void IR_init();
void IR_Send(u8 data);

#endif /* REMOTER_H_ */
