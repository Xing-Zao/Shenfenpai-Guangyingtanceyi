/**
 * 光影探测仪 Firmware
 * Copyright (c) 2020-2021 LonlyPan. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
/*
 * @file         : \user\remoter.c
 * @author       : LonlyPan
 * @version      : V0.0.0
 * @date         : 2021-01-06 14:12
 * @brief        : 红外遥控驱动
 * @attention    : PWM方式
 */


#include "remoter.h"

/**
 * @brief: 初始化、使能PWM输出
 */
void IR_init()
{
	HAL_TIM_PWM_Start(&IR_time,TIM_CHANNEL_2);//开启PWM通道1
}

/**
 * @brief: 发送一个字节信息
 * @note: 
 * @param {u8} getdata 要发送的数据
 */
void IR_Send_Byte(u8 getdata)
{
	u8 senddata,i;
	senddata=getdata;
	for(i=0;i<8;i++)
	{
		if(senddata&0x80)
		{
			//1
			HAL_TIM_PWM_Start(&IR_time,TIM_CHANNEL_2);
			delay_us(565);
			HAL_TIM_PWM_Stop(&IR_time,TIM_CHANNEL_2);
			delay_us(565);
			delay_us(565);
			delay_us(565);
		}
		else
		{
			//0
			HAL_TIM_PWM_Start(&IR_time,TIM_CHANNEL_2);
			delay_us(565);
			HAL_TIM_PWM_Stop(&IR_time,TIM_CHANNEL_2);
			delay_us(565);
		}
		senddata=senddata<<1;
	}
}

/**
 * @brief: 发送一次数据
 * @note: 红外发射信息中不仅有发送的数据，还包含引导码、地址码等
 * @param {u8} data 要发送的数据
 */
void IR_Send(u8 data)
{
	//引导码
	HAL_TIM_PWM_Start(&IR_time,TIM_CHANNEL_2);
	delay_ms(9);  //9ms
	HAL_TIM_PWM_Stop(&IR_time,TIM_CHANNEL_2);
	delay_ms(4);  //4.5ms
	delay_us(500);

	IR_Send_Byte(0x00); //地址码
	IR_Send_Byte(0xFF); //地址反码
	IR_Send_Byte(data); //数据码
	IR_Send_Byte(~data); //数据反码
	//下面增加是为了避免在发送最后一位时出现错码
	HAL_TIM_PWM_Start(&IR_time,TIM_CHANNEL_2);
	delay_us(565);
	HAL_TIM_PWM_Stop(&IR_time,TIM_CHANNEL_2);
	delay_us(565);
}
