/**
 * 光影探测仪 Firmware
 * Copyright (c) 2020-2021 LonlyPan. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */
/*
 * @file         : \user\task.c
 * @author       : LonlyPan
 * @version      : V0.0.0
 * @date         : 2021-03-13 17:15
 * @brief        : 主要功能实现，系统的每种工作状态
 * @attention    : 如若要添加新的功能，请在对应状态函数中修改
 * @Modefication : 初始版本
 * @LastEditTime : 2021-03-17 10:01
 * @History      : 
 *   1.Version: 
 *     Author:
 *     date:    
 *     Modification: 
 *   2.Version: 
 *     ......
 */
#ifndef TASK_H_
#define TASK_H_

#include "Comheader.h"



typedef void (*modeFunc_t)();  // 函数指针
extern modeFunc_t currentMode;

void key_process();
void standby_mode();
void power_on_mode();
void power_off_mode();
void normal_mode();
void wing_turn_mode();
void wing_turn_next_mode();
void modify_mode();
#endif /* TASK_H_ */
